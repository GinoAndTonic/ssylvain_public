import os
os.chdir(r"S:\PMG\MAS\MAPS\Research\ssylvain\MAS Projects\Inflation\InflationRiskPremia\python")
#execfile("call_estimation.py")
execfile("testing1.py")
